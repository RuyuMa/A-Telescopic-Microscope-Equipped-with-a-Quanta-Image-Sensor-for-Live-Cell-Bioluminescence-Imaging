import argparse
import torch
import numpy as np
import tifffile
import os
from tqdm import tqdm

from torchvision.transforms import v2 

from net3 import Net


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

parser = argparse.ArgumentParser(description='noise2noise')
parser.add_argument('--input', type=str, required=True) # folder with data
parser.add_argument('--weights', type=str, required=True) # actual file
opt = parser.parse_args()

net = Net(in_channels=3, out_channels=1).to(device)
print(' > model initialised')

net.load_state_dict(torch.load(opt.weights))
print(' > weights loaded')

paths = np.sort(os.listdir(opt.input))

outputs = []
for index in tqdm(range(len(paths) - 2)):
    imgs = np.array(
        [
            tifffile.imread(os.path.join(opt.input,paths[index])),
            tifffile.imread(os.path.join(opt.input,paths[index+1])),
            tifffile.imread(os.path.join(opt.input,paths[index+2])),
        ]
    ).astype(np.float32)
    imgs = imgs[:,1280:-1280,1280:-1280]
    # imgs = imgs[:,1500:2524,2600:3624]
    # imgs = np.clip(imgs, 0, 8)

    imgs = imgs / np.max(imgs)
    imgs = np.moveaxis(imgs, 0, -1)

    transform = v2.Compose([v2.ToTensor(),])

    im_torch = transform(imgs).unsqueeze(0).to(device)

    output = net(im_torch)
    outputs.append(output.detach().cpu().numpy())


print(' > images processed')

np.save('output-video.npy', np.array(outputs))
