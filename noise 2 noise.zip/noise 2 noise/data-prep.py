import os 
from tqdm import tqdm
import numpy as np
import tifffile

import torch
from torch.utils.data import Dataset, DataLoader

from torchvision.transforms import v2 
from torchvision import models

# from networks.skip import skip
from net3 import Net



device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def crop_parameters(X_shape, crop_size):
    '''
    Assumes X_shape has shape (H,W).
    '''
    h, w = np.random.randint(0, X_shape[0] - crop_size), np.random.randint(0, X_shape[1] - crop_size)
    return h, w



class MeanData(Dataset):
    '''
    Reads paths of tiff files in folder PATH, the images are then read when indexed to save memory.
    '''
    def __init__(self, PATH, window_size, crop_size, train=True):

        assert window_size % 2 == 1, "window_size must be odd"

        self.PATH = PATH
        self.crop_size = crop_size
        self.window_size = window_size
        self.start_index = window_size // 2
        self.CROPS_PER_IMAGE = 24

        all_paths = np.sort(os.listdir(PATH))[:200]
        print(' > > > paths limitation for memory saving')
        self.paths = all_paths

        self.iterable_paths = len(self.paths) - self.start_index * 2

        print(" > loading crops into memory")
        self.A_crops, self.B_crops = self.get_crops()

        print(" > loaded crops shape: {}".format(np.array(self.A_crops).shape))

        print(" ! > function get_crops in dataloader crops the inputs")
        # print(" ! > function get_crops in dataloader applies gamma transform")


    def __len__(self):
        return len(self.A_crops)


    def get_crops(self):
        A_crops, B_crops = [], []

        for path_index in tqdm(range(self.iterable_paths)):
            # get paths
            # A_path =  os.path.join(self.PATH, self.paths[path_index + self.start_index])
            A_paths = [os.path.join(self.PATH, self.paths[j]) for j in range(path_index + self.start_index - 1, path_index + self.start_index + 2)]
            B_paths = [os.path.join(self.PATH, self.paths[j]) for j in range(path_index, path_index + 2 * self.start_index + 1)]

            # read input image
            A_imgs = np.array([tifffile.imread(path)[1024:-1024,1024:-1024] for path in A_paths]).astype(np.float32)
            # A_imgs = np.array([np.clip(tifffile.imread(path)[1024:-1024,1024:-1024], 0, 8) for path in A_paths]).astype(np.float32)
            # A_imgs = np.array([tifffile.imread(path) for path in A_paths]).astype(np.float32)


            # read the sliding window and make frame mean
            B_imgs = np.array([tifffile.imread(path) for path in B_paths])
            # B_imgs = np.array([np.clip(tifffile.imread(path), 0, 8) for path in B_paths])
            B_img = np.mean(B_imgs[:,1024:-1024,1024:-1024], axis=0).astype(np.float32)

            # normalize
            A_imgs = A_imgs / np.max(A_imgs)
            B_img = B_img / np.max(B_img)


            for _ in range(self.CROPS_PER_IMAGE):
                # find parameters for random crop
                h, w = crop_parameters(B_img.shape, crop_size=self.crop_size)

                # do the cropping
                A_img_cropped, B_img_cropped = A_imgs[:,h:h+self.crop_size,w:w+self.crop_size], B_img[h:h+self.crop_size,w:w+self.crop_size]
                A_img_cropped = np.moveaxis(A_img_cropped, 0, -1)


                transform = v2.Compose([
                    v2.ToTensor(),
                ]) 

                A_crop, B_crop = transform(A_img_cropped), transform(B_img_cropped)

                A_crops.append(A_crop)
                B_crops.append(B_crop)

        return A_crops, B_crops


    def __getitem__(self, idx):
        return self.A_crops[idx], self.B_crops[idx]


def main():
    FRAMES_PATH = '../data/video5/2s/'
    WINDOW_SIZE = 7
    CROP_SIZE = 256
    BATCH_SIZE = 16

    EPOCHS = 50 # 50 for all
    LR = 1e-4

    if not os.path.isdir('output'):
        os.mkdir('output')


    print(' > device: {}'.format(device))

    train_data = MeanData(FRAMES_PATH, WINDOW_SIZE, CROP_SIZE)
    print(' > train dataset prepared')
    train_dataloader = DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True)
    print(' > train dataloader prepared')

    net = Net(in_channels=3, out_channels=1).to(device)
    print(' > model initialised')


    mse_loss = torch.nn.MSELoss()
    optimizer = torch.optim.NAdam([{'params':net.parameters()}], lr=LR)


    for epoch in range(EPOCHS):
        epoch_losses = []
        net.train()
        with tqdm(train_dataloader, unit="batch") as tepoch:
            for input, target in tepoch:
                tepoch.set_description(f"Epoch {epoch}")

                input, target = input.to(device), target.to(device)

                optimizer.zero_grad()

                output = net(input)

                indices = input < 0.4  # 0.4
                loss = mse_loss(output * indices, target * indices[1])

                loss.backward()
                optimizer.step()

                epoch_losses.append(loss.item())

                tepoch.set_postfix(loss=np.mean(np.array(epoch_losses)))


    torch.save(net.state_dict(), 'noise2noise.pth')
            

if __name__ == "__main__":
    main()
