import numpy as np
import tifffile
import argparse
import os, fnmatch, cv2

from models import Noise2Info

# ------------------------------------------------------------------------------------

def normalize_mi_ma(x, mi, ma, clip=False, eps=1e-20, dtype=np.float32):
    if dtype is not None:
        x   = x.astype(dtype,copy=False)
        mi  = dtype(mi) if np.isscalar(mi) else mi.astype(dtype,copy=False)
        ma  = dtype(ma) if np.isscalar(ma) else ma.astype(dtype,copy=False)
        eps = dtype(eps)
    try:
        import numexpr
        x = numexpr.evaluate("(x - mi) / ( ma - mi + eps )")
    except ImportError:
        x =                   (x - mi) / ( ma - mi + eps )
    if clip:
        x = np.clip(x,0,1)
    return x

def normalize(x, pmin=2, pmax=99.8, axis=None, clip=False, eps=1e-20, dtype=np.float32):
    """Percentile-based image normalization."""

    mi = np.percentile(x,pmin,axis=axis,keepdims=True)
    ma = np.percentile(x,pmax,axis=axis,keepdims=True)
    return normalize_mi_ma(x, mi, ma, clip=clip, eps=eps, dtype=dtype)

# ------------------------------------------------------------------------------------

parser = argparse.ArgumentParser(description='noise2info')
parser.add_argument('--input_folder', type=str, required=True)
parser.add_argument('--patch_size', type=int, default=64)
parser.add_argument('--update_steps', type=int, default=1000)
parser.add_argument('--train_steps', type=int, default=50000)
opt = parser.parse_args()

print(' > input fodler: {}'.format(opt.input_folder))

X_data = []

for file_path in np.sort(os.listdir(opt.input_folder))[200:210]:

    # if not ('b' in file_path): continue

    print('    > file path: {}'.format(file_path))
    X = tifffile.imread(os.path.join(opt.input_folder, file_path))
    X = X[X.shape[0]//4:-X.shape[0]//4,X.shape[1]//4:-X.shape[1]//4]
    print(' > clipping for new PINK1 data')
    X = np.clip(X,0,8)

    X_data.append(X)

print(' > loaded image data shape: {}'.format(np.array(X_data).shape))

X_data = np.array([(x - x.mean())/x.std() for x in X_data]).astype('float32')
print(' > images normalized')

print(' > min: {}, max: {}'.format(np.min(X_data), np.max(X_data)))

model = Noise2Info(
    'trained_models/', 
    'denoising_bio',
    dim=2, 
    in_channels=1, 
    update_per_steps=opt.update_steps,
)
print(' > model initialized')

model.train(
    X_data[...,None], 
    patch_size=[opt.patch_size, opt.patch_size], 
    batch_size=64, 
    steps=opt.train_steps,
)
print(' > training done')

pred_data = []
for X_slice in X_data:
    pred = model.batch_predict(np.array([X_slice]).astype('float32'), batch_size=1)
    pred_data.append(normalize(pred))
print(' > inference done')

np.save('output.npy', np.array(pred_data))
